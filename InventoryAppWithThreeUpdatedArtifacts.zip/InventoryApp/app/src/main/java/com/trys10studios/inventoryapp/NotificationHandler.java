package com.trys10studios.inventoryapp;

public interface NotificationHandler {
    void sendSms(String message);
}
